//
//  FoodBanksList.swift
//  MiniChallenge2
//
//  Created by shahadmufleh on 24/01/2022.
//

import SwiftUI

struct FoodBanksList: View {
    var body: some View {
        LandmarkList()
    }
}

struct FoodBanksList_Previews: PreviewProvider {
    static var previews: some View {
        FoodBanksList()
    }
}
