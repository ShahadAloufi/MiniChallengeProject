//
//  Landmark.swift
//  NearFoodBank
//
//  Created by Rahaf Alhubeis on 17/06/1443 AH.
//

import Foundation
import MapKit
import SwiftUI
import CoreLocation

struct Landmark {
    
    let placemark: MKPlacemark
    
    var id: UUID {
        return UUID()
    }
    
    var name: String {
        self.placemark.name ?? ""
    }
    
    var title: String {
        self.placemark.title ?? ""
    }

    
    
    var coordinate: CLLocationCoordinate2D {
        self.placemark.coordinate
    }
}

struct Landmark2: Hashable, Codable, Identifiable {
    var id: Int
    var name: String
    var park: String
    var state: String
    var description: String

    private var imageName: String
    var image: Image {
        Image(imageName)
    }

    private var coordinates: Coordinates
    var locationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(
            latitude: coordinates.latitude,
            longitude: coordinates.longitude)
    }

    struct Coordinates: Hashable, Codable {
        var latitude: Double
        var longitude: Double
    }
}
