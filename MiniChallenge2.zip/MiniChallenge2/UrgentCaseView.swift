//
//  UrgentCaseView.swift
//  MiniChallenge2
//
//  Created by shahadmufleh on 24/01/2022.
//

import SwiftUI

struct UrgentCaseView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct UrgentCaseView_Previews: PreviewProvider {
    static var previews: some View {
        UrgentCaseView()
    }
}
