//
//  HomeView1.swift
//  MiniChallenge2
//
//  Created by shahadmufleh on 22/01/2022.
//

import SwiftUI

struct HomeView1: View {
    var body: some View {
        TabView{
            
            
            
            
        }
        
        
        
    }
}

struct HomeView1_Previews: PreviewProvider {
    static var previews: some View {
        HomeView1()
    }
}
